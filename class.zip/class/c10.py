
class Cricket_Personalities:
    sport_played = "Cricket"

    def __init__(self, fname, lname):
        print("I am called always on declaration of object")
        self.firstname = fname
        self.lastname = lname


    def printname(self):
        print(self.firstname, self.lastname)


# Use the Person class to create an object, and then execute the printname method:

x = Cricket_Personalities("Sachin", "Tendulkar")
x.printname()
print(x.sport_played)

y = Cricket_Personalities("Rahul", "Dravid")
y.printname()

##End of Program