#Super  Python code to demonstrate how parent constructors
# are called.

# parent class
class Person(object):

    # __init__ is known as the constructor
    def __init__(self, name, idnumber):
        self.name = name
        self.idnumber = idnumber

    def display(self):
        print(self.name)
        print(self.idnumber)

    # child class


class Employee(Person):
    def __init__(self, name, idnumber, salary, post):
        self.salary = salary
        self.post = post

        # invoking the __init__ of the parent class
        Person.__init__(self, name, idnumber)  #important to declare to get base class vars

    def display(self):
        Person.display(self)
        print(self.salary)
        print(self.post)



    # creation of an object variable or an instance


p1 = Person('Rahul', 886012)
# calling a function of the class Person using its instance
p1.display()


p2 = Employee('Ashish', 105, 5000, "VP")
# calling a function of the class Person using its instance
p2.display()


##End of Program