# If you forget to invoke the __init__() of the parent class then its instance variables would not be available to the child class.
# The following code produces an error for the same reason.
# Python program to demonstrate error if we
# forget to invoke __init__() of parent.

class A:
    def __init__(self, n='Rahul'):
        self.name = n


class B(A):
    def __init__(self, roll):
        self.roll = roll


object = B(23)
print(object.name) #AttributeError: 'B' object has no attribute 'name'


##End of Program